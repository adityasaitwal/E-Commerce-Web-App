import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboardc',
  templateUrl: './dashboardc.component.html',
  styleUrls: ['./dashboardc.component.css']
})
export class DashboardcComponent {

}
